# CatfishCheck

Detect stolen or fake dating profile photos using AI visual analysis + live web search.

## How it works

1. User uploads a profile photo screenshot
2. Claude AI analyzes it visually for red flags (stock photo style, professional lighting, etc.)
3. AI generates targeted web search queries based on the photo description
4. Live web searches check scam report sites, catfish databases, and social media
5. Final risk verdict (High / Medium / Low) with key findings and next steps

---

## Local setup

### Requirements
- Node.js 18 or higher
- An [Anthropic API key](https://console.anthropic.com/settings/keys)

### Steps

```bash
# 1. Install dependencies
npm install

# 2. Create your .env file
cp .env.example .env

# 3. Add your API key to .env
# Open .env and replace the placeholder:
ANTHROPIC_API_KEY=sk-ant-your-real-key-here

# 4. Start the server
npm start

# 5. Open in browser
# http://localhost:3000
```

---

## Deploy to Vercel (free, gets you a public URL)

### Option A — Vercel CLI (fastest)

```bash
# Install Vercel CLI
npm install -g vercel

# Deploy from the project folder
vercel

# Follow the prompts, then add your API key:
vercel env add ANTHROPIC_API_KEY
# Paste your key when prompted

# Redeploy with the env var
vercel --prod
```

Your app will be live at a URL like `https://catfishcheck-yourname.vercel.app`

### Option B — Vercel Dashboard (no CLI)

1. Push this folder to a GitHub repo
2. Go to [vercel.com](https://vercel.com) → New Project → Import your repo
3. In Project Settings → Environment Variables, add:
   - Name: `ANTHROPIC_API_KEY`
   - Value: your key from [console.anthropic.com](https://console.anthropic.com/settings/keys)
4. Click Deploy

---

## Deploy to Render (also free)

1. Push to GitHub
2. Go to [render.com](https://render.com) → New Web Service → Connect your repo
3. Set:
   - Build command: `npm install`
   - Start command: `npm start`
4. Add environment variable: `ANTHROPIC_API_KEY`
5. Deploy

---

## Project structure

```
catfishcheck/
├── public/
│   └── index.html      # Frontend UI
├── server.js           # Express backend + API routes
├── package.json
├── vercel.json         # Vercel deployment config
├── .env.example        # Template for environment variables
├── .env                # Your actual keys (never commit this)
└── .gitignore
```

## API routes

| Route | Method | Description |
|-------|--------|-------------|
| `/api/analyze` | POST | Visual AI analysis of the photo |
| `/api/search` | POST | Web search for scam patterns |
| `/api/verdict` | POST | Final risk verdict synthesis |

---

## Privacy

- No photos are stored on the server
- Images are sent directly to Anthropic's API for analysis and discarded
- No user data is logged or retained

---

## Limitations

- AI analysis is a first-pass screen, not definitive proof
- Newly created fake profiles may not yet appear in scam databases
- Always supplement with manual reverse image search (Google Images, TinEye, Yandex)
