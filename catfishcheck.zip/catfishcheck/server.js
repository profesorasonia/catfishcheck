require('dotenv').config();
const express = require('express');
const path = require('path');

const app = express();
app.use(express.json({ limit: '20mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const ANTHROPIC_API = 'https://api.anthropic.com/v1/messages';
const MODEL = 'claude-sonnet-4-20250514';

function getHeaders() {
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) throw new Error('ANTHROPIC_API_KEY not set in environment');
  return {
    'Content-Type': 'application/json',
    'x-api-key': key,
    'anthropic-version': '2023-06-01',
  };
}

async function callClaude(body) {
  const fetch = (await import('node-fetch')).default;
  const res = await fetch(ANTHROPIC_API, {
    method: 'POST',
    headers: getHeaders(),
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Anthropic API error ${res.status}: ${err}`);
  }
  return res.json();
}

function parseJSON(text) {
  return JSON.parse(text.replace(/```json|```/g, '').trim());
}

// Route 1: Visual analysis
app.post('/api/analyze', async (req, res) => {
  try {
    const { base64, mediaType } = req.body;
    if (!base64 || !mediaType) return res.status(400).json({ error: 'Missing base64 or mediaType' });

    const data = await callClaude({
      model: MODEL,
      max_tokens: 1000,
      system: `You are an expert at analyzing profile photos for catfishing and romance scam detection.
Analyze the image and return ONLY valid JSON, no markdown, no extra text.
{
  "description": "Detailed visual description: apparent gender, approximate age, ethnicity, hair color/style, notable features, clothing style, setting/background, lighting quality, photo style (selfie/professional/candid), image quality",
  "photoStyle": "selfie|professional|candid|stock|unknown",
  "suspiciousSignals": ["list of red flags"],
  "trustSignals": ["list of authentic signals"],
  "searchQueries": ["3-5 specific web search queries to find scam reports matching this photo"],
  "notableDetails": "Any unique identifiable details: tattoos, jewelry, background landmarks, watermarks"
}`,
      messages: [{
        role: 'user',
        content: [
          { type: 'image', source: { type: 'base64', media_type: mediaType, data: base64 } },
          { type: 'text', text: 'Analyze this dating profile photo for authenticity. Return only the JSON.' }
        ]
      }]
    });

    const text = data.content.map(b => b.text || '').join('');
    res.json(parseJSON(text));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Route 2: Web search
app.post('/api/search', async (req, res) => {
  try {
    const { analysis } = req.body;
    if (!analysis) return res.status(400).json({ error: 'Missing analysis' });

    const data = await callClaude({
      model: MODEL,
      max_tokens: 1000,
      tools: [{ type: 'web_search_20250305', name: 'web_search' }],
      system: `You are a romance scam investigator. Use web_search to run the provided queries.
Look for: scam report sites, reverse image search matches, catfish databases, romance scam forums, social media profiles.
After all searches, return ONLY valid JSON:
{
  "searchesPerformed": ["query1","query2"],
  "webFindings": [{"title":"","url":"","snippet":"","relevance":""}],
  "scamPatternMatches": ["patterns found"],
  "platformMentions": ["platforms where photo appeared"]
}`,
      messages: [{
        role: 'user',
        content: `Search for scam reports matching this person.
Photo description: ${analysis.description}
Notable details: ${analysis.notableDetails}
Run these searches: ${analysis.searchQueries.join(' | ')}
Return only the JSON.`
      }]
    });

    const text = data.content.filter(b => b.type === 'text').map(b => b.text || '').join('');
    try {
      res.json(parseJSON(text));
    } catch {
      res.json({ searchesPerformed: [], webFindings: [], scamPatternMatches: [], platformMentions: [] });
    }
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Route 3: Final verdict
app.post('/api/verdict', async (req, res) => {
  try {
    const { analysis, webResults } = req.body;
    if (!analysis || !webResults) return res.status(400).json({ error: 'Missing data' });

    const data = await callClaude({
      model: MODEL,
      max_tokens: 1000,
      system: `You are a romance scam detection expert. Return ONLY valid JSON:
{
  "riskLevel": "HIGH|MEDIUM|LOW|UNKNOWN",
  "verdict": "2-3 sentence plain-language verdict for a non-expert",
  "keyFindings": ["top 3-5 findings combining visual + web results"],
  "tips": ["2-3 specific next steps"],
  "confidence": "HIGH|MEDIUM|LOW"
}`,
      messages: [{
        role: 'user',
        content: `Give a final verdict on this dating profile photo.

Visual: photoStyle=${analysis.photoStyle}, suspicious=${JSON.stringify(analysis.suspiciousSignals)}, trust=${JSON.stringify(analysis.trustSignals)}

Web results: findings=${JSON.stringify(webResults.webFindings)}, scamPatterns=${JSON.stringify(webResults.scamPatternMatches)}

Return the JSON verdict.`
      }]
    });

    const text = data.content.map(b => b.text || '').join('');
    res.json(parseJSON(text));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`CatfishCheck running at http://localhost:${PORT}`);
  if (!process.env.ANTHROPIC_API_KEY) {
    console.warn('WARNING: ANTHROPIC_API_KEY is not set. Add it to your .env file.');
  }
});
